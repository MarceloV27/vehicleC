package Vehicle;

public class VehicleDemo {
	
	public static void main(String args[]) {
		
		// object method();
		Vehicle ambulance = new Vehicle (); 
		Vehicle bus = new Vehicle ();
		
		
		// Object method with variables();
		ambulance.passengers = 60;
		ambulance.fuelcap = 12;
		ambulance.mpg = 70;
		
		bus.passengers = 55;
	    bus.fuelcap = 32;
		bus.mpg = 74;
		
		
		// Display 
		System.out.println("Ambulance can carry "+ ambulance.passengers + "." ); 
		ambulance.range();
		
		System.out.println();
		
		System.out.println("Bus can carry " +bus.passengers + ".");
		bus.range();
	
	}	
	
}
