package Vehicle;

public class Vehicle {
	
	// variable class vehicle 
	int passengers;
	int fuelcap;
	int mpg;
	
	
	
	// Method range ();
	void range() {
		System.out.println("Range is " + fuelcap * mpg);
	}
}
